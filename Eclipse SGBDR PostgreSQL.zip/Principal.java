public class Principal {
    public static void main(String[] args) {
        ClasseXDAO dao = new ClasseXDAO();
        int opcao;

        do {
            // Exibir opções do menu
            System.out.println("1. Listar");
            System.out.println("2. Inserir");
            System.out.println("3. Excluir");
            System.out.println("4. Atualizar");
            System.out.println("5. Sair");

            // Ler opção do usuário
            opcao = lerOpcaoDoUsuario();

            // Executar ação correspondente à opção escolhida
            switch (opcao) {
                case 1:
                    dao.listarRegistros();
                    break;
                case 2:
                    dao.inserirRegistro();
                    break;
                case 3:
                    dao.excluirRegistro();
                    break;
                case 4:
                    dao.atualizarRegistro();
                    break;
                case 5:
                    System.out.println("Saindo do programa. Até logo!");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        } while (opcao != 5);
    }

    private static int lerOpcaoDoUsuario() {
        // Lógica para ler e retornar a opção do usuário
        // (pode usar Scanner ou outra abordagem de leitura de entrada)
    }
}
