import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ClasseXDAO {
    private static final String URL = "jdbc:postgresql://localhost:5432/seu_banco_de_dados";
    private static final String USUARIO = "seu_usuario";
    private static final String SENHA = "sua_senha";

    // Método para estabelecer a conexão com o banco de dados
    private Connection conectar() throws SQLException {
        return DriverManager.getConnection(URL, USUARIO, SENHA);
    }

    // Método para fechar a conexão com o banco de dados
    private void fecharConexao(Connection conn) throws SQLException {
        if (conn != null && !conn.isClosed()) {
            conn.close();
        }
    }

    // Método para listar todos os registros da tabela
    public List<ClasseX> listarRegistros() {
        List<ClasseX> registros = new ArrayList<>();
        Connection conn = null;

        try {
            conn = conectar();

            // Consulta SQL para selecionar todos os registros da tabela
            String sql = "SELECT * FROM tabela_x";
            PreparedStatement stmt = conn.prepareStatement(sql);

            ResultSet rs = stmt.executeQuery();

            // Itera sobre os resultados e cria objetos ClasseX
            while (rs.next()) {
                int id = rs.getInt("id");
                String nome = rs.getString("nome");
                int idade = rs.getInt("idade");

                ClasseX registro = new ClasseX(id, nome, idade);
                registros.add(registro);
            }

            // Fechar recursos
            rs.close();
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                fecharConexao(conn);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        // Retorna a lista de registros
        return registros;
    }

    // Outros métodos CRUD (inserir, excluir, atualizar) podem ser implementados aqui
    // Exemplo de inserção de registro
    public void inserirRegistro(ClasseX registro) {
        Connection conn = null;

        try {
            conn = conectar();

            // Consulta SQL para inserir um registro na tabela
            String sql = "INSERT INTO tabela_x (nome, idade) VALUES (?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);

            // Configura os parâmetros da consulta com os valores do objeto ClasseX
            stmt.setString(1, registro.getNome());
            stmt.setInt(2, registro.getIdade());

            // Executa a consulta
            stmt.executeUpdate();

            // Fechar recursos
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                fecharConexao(conn);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
}


